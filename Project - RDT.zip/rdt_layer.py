# Name: Casey Levy
# CS 372 - RDT
# Description: Writing an RDT layer that allows the transfer of string data through 
#              an unreliable channel in a simulated environment. 
# Sources Cited:
# "Computer Networking: A Top-Down Approach", Kurose & Ross, 7th Edition
# The given skeleton code
# https://alphazwest.medium.com/reliable-data-transfer-protocols-rdt-the-reliability-guarantee-that-keeps-the-internet-running-e555a4fb375d
# https://realpython.com/python-sort/#ordering-values-with-sort
# https://pythonexamples.org/python-split-string-into-specific-length-chunks/



from segment import Segment


# #################################################################################################################### #
# RDTLayer                                                                                                             #
#                                                                                                                      #
# Description:                                                                                                         #
# The reliable data transfer (RDT) layer is used as a communication layer to resolve issues over an unreliable         #
# channel.                                                                                                             #
#                                                                                                                      #
#                                                                                                                      #
# Notes:                                                                                                               #
# This file is meant to be changed.                                                                                    #
#                                                                                                                      #
#                                                                                                                      #
# #################################################################################################################### #


class RDTLayer(object):
    # ################################################################################################################ #
    # Class Scope Variables                                                                                            #
    #                                                                                                                  #
    #                                                                                                                  #
    #                                                                                                                  #
    #                                                                                                                  #
    #                                                                                                                  #
    # ################################################################################################################ #
    DATA_LENGTH = 4 # in characters                     # The length of the string data that will be sent per packet...
    FLOW_CONTROL_WIN_SIZE = 15 # in characters          # Receive window size for flow-control
    sendChannel = None
    receiveChannel = None
    dataToSend = ''
    currentIteration = 0                                # Use this for segment 'timeouts'

    # Add items as needed
    data_list = []
    current_seq = 0
    without_ACK = 0
    expect_ACK = 4
    current_window = [0,4]

    # ################################################################################################################ #
    # __init__()                                                                                                       #
    #                                                                                                                  #
    #                                                                                                                  #
    #                                                                                                                  #
    #                                                                                                                  #
    #                                                                                                                  #
    # ################################################################################################################ #
    def __init__(self):
        self.sendChannel = None
        self.receiveChannel = None
        self.dataToSend = ''
        self.currentIteration = 0

        # Add items as needed
        self.id = "Server"
        self.waiting = 0
        self.current_ACK = 0
        self.countSegmentTimeouts = 0
        self.window_begin = 0
        self.window_end = 4


    # ################################################################################################################ #
    # setSendChannel()                                                                                                 #
    #                                                                                                                  #
    # Description:                                                                                                     #
    # Called by main to set the unreliable sending lower-layer channel                                                 #
    #                                                                                                                  #
    #                                                                                                                  #
    # ################################################################################################################ #
    def setSendChannel(self, channel):
        self.sendChannel = channel

    # ################################################################################################################ #
    # setReceiveChannel()                                                                                              #
    #                                                                                                                  #
    # Description:                                                                                                     #
    # Called by main to set the unreliable receiving lower-layer channel                                               #
    #                                                                                                                  #
    #                                                                                                                  #
    # ################################################################################################################ #
    def setReceiveChannel(self, channel):
        self.receiveChannel = channel

    # ################################################################################################################ #
    # setDataToSend()                                                                                                  #
    #                                                                                                                  #
    # Description:                                                                                                     #
    # Called by main to set the string data to send                                                                    #
    #                                                                                                                  #
    #                                                                                                                  #
    # ################################################################################################################ #
    def setDataToSend(self,data):
        self.dataToSend = data

    # ################################################################################################################ #
    # getDataReceived()                                                                                                #
    #                                                                                                                  #
    # Description:                                                                                                     #
    # Called by main to get the currently received and buffered string data, in order                                  #
    #                                                                                                                  #
    #                                                                                                                  #
    # ################################################################################################################ #
    def getDataReceived(self):
        # ############################################################################################################ #
        # Identify the data that has been received...
        # print('getDataReceived(): Complete this...')
        data_sort = sorted(self.data_list)
        string_sort = ""
        for x in range(len(data_sort)):
            string_sort += data_sort[x][1]

        return string_sort

    # ################################################################################################################ #
    # processData()                                                                                                    #
    #                                                                                                                  #
    # Description:                                                                                                     #
    # "timeslice". Called by main once per iteration                                                                   #
    #                                                                                                                  #
    #                                                                                                                  #
    # ################################################################################################################ #
    def processData(self):
        self.currentIteration += 1
        self.processSend()
        self.processReceiveAndSendRespond()

    # ################################################################################################################ #
    # processSend()                                                                                                    #
    #                                                                                                                  #
    # Description:                                                                                                     #
    # Manages Segment sending tasks                                                                                    #
    #                                                                                                                  #
    #                                                                                                                  #
    # ################################################################################################################ #
    def processSend(self):
        
        # ############################################################################################################ #
        # print('processSend(): Complete this...')
        # You should pipeline segments to fit the flow-control window
        # The flow-control window is the constant RDTLayer.FLOW_CONTROL_WIN_SIZE
        # The maximum data that you can send in a segment is RDTLayer.DATA_LENGTH
        # These constants are given in # characters


        if(self.dataToSend != ""):
            self.id = "Client"

        # https://pythonexamples.org/python-split-string-into-specific-length-chunks/
        # Splitting string into segs of same size as self.DATA_LENGTH
        data_split = [self.dataToSend[x:x + self.DATA_LENGTH] for x in range(0, len(self.dataToSend), self.DATA_LENGTH)]

        if(self.currentIteration > 1 and len(self.receiveChannel.receiveQueue ) == 0):
            if(self.waiting == 3):
                self.current_seq = self.current_window[0]
                self.countSegmentTimeouts += 1

            else:
                self.waiting += 1
                return

        if(len(self.receiveChannel.receiveQueue) > 0 and self.id == "Client"):
            acks = self.receiveChannel.receive()
            self.check_For_ACK(acks)

        # Somewhere in here you will be creating data segments to send.
        # The data is just part of the entire string that you are trying to send.
        # The seqnum is the sequence number for the segment (in character number, not bytes)

        seqnum = self.current_seq
        self.window_begin = seqnum
        self.window_end = seqnum + 4

        if(self.id != "server"):
            self.data_Send(self.window_begin, self.window_end, seqnum, data_split, len(data_split))



    def check_For_ACK(self, check):
        for x in range(0, len(check)):
            if(check[x].acknum == self.expect_ACK):
                self.expect_ACK += 4
                self.current_seq += 4
                self.current_window[0] += 4
                self.current_window[1] += 4

        return


    def data_Send(self, begin, end, seqnum, arr, size):
        for x in range(begin, end):
            if(self.dataToSend != "" and seqnum < len(arr)):
                segmentSend = Segment()
                data = arr[seqnum]
                # Display sending segment
                segmentSend.setData(seqnum, data)
                print("Sending segment: ", segmentSend.to_string())
                seqnum += 1

                segmentSend.setStartIteration(self.currentIteration)
                segmentSend.setStartDelayIteration(4)
                # Use the unreliable sendChannel to send the segment
                self.sendChannel.send(segmentSend)
        return
        


    # ################################################################################################################ #
    # processReceive()                                                                                                 #
    #                                                                                                                  #
    # Description:                                                                                                     #
    # Manages Segment receive tasks                                                                                    #
    #                                                                                                                  #
    #                                                                                                                  #
    # ################################################################################################################ #
    def processReceiveAndSendRespond(self):
        

        # This call returns a list of incoming segments (see Segment class)...
        listIncomingSegments = self.receiveChannel.receive()

        # ############################################################################################################ #
        # What segments have been received?
        # How will you get them back in order?
        # This is where a majority of your logic will be implemented
        # print('processReceive(): Complete this...')
         
        if(len(listIncomingSegments) > 0):
            segmentAck = Segment()                  # Segment acknowledging packet(s) received
            ack_current = self.current_window[0]
            self.expect_ACK = self.current_window[1]
            list_new, rec_ack = self.process_List(listIncomingSegments)
            ack_current += rec_ack

            if(ack_current == self.expect_ACK):
                self.window_begin += 4
                self.current_ACK = self.current_ACK + 4
                # Display response segment
                segmentAck.setAck(ack_current)
                # Use the unreliable sendChannel to send the ack packet
                self.sendChannel.send(segmentAck)  
                print("Sending ack: ", segmentAck.to_string())


            self.add_List(list_new)

        else:
            return



    def add_List(self, add):
        for x in range(len(add)):
            if(add[x] not in self.data_list):
                self.data_list.append(add[x])



    def process_List(self, process):
        seq_payload = []
        to_process = []

        for x in range(len(process)):
            if(process[x].payload != "" and process[x].checkChecksum() == True):
                seq_payload.append([process[x].seqnum, process[x].payload])

        for y in range(len(seq_payload)):
            if(seq_payload[y] not in to_process and (self.current_window[0] <= seq_payload[y][0] <= self.current_window[1])):
                to_process.append(seq_payload[y])

        return to_process, len(to_process)
